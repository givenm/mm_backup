<?php include 'slide-text.inc.php';?>
</div> <!-- slide-title-url-wrap -->