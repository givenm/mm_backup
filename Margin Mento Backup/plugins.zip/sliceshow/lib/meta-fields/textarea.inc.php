<th><label for="<?php echo $field['id']; ?>"><?php echo $field['label']; ?></label></th>
<td><<textarea name="<?php echo $field['id']; ?>" id="<?php echo $field['id']; ?>" class="<?php echo $field['class']; ?><?php echo $req; ?>" cols="60" rows="4"><?php echo $meta; ?></textarea>
<br /><span class="description"><?php echo $field['desc']; ?></span></td>