<th><label for="<?php echo $field['id']; ?>"><?php echo $field['label']; ?></label></th>
<td><input type="text" name="<?php echo $field['id']; ?>" id="<?php echo $field['id']; ?>" value="<?php echo $meta; ?>" class="<?php echo $field['class']; ?><?php echo $req; ?>" size="30" />
<br /><span class="description"><?php echo $field['desc']; ?></span></td>