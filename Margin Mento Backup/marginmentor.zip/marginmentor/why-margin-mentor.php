	<div class="row-fluid span8 offset2 main-content">
		<div class="row-fluid info-content">
			<div class="row-fluid info-content-strip strip-1" style="margin-top:60px; margin-bottom: 65px;">
				<div class="row-fluid page-top-heading">
					<div class="span12">
						<div>Instantly know your company&#39;s</div>
						<div> financial position</div>
					</div>
				</div>
				<div class="row-fluid">
					<div class="span12">Margin Mentor  pulls all your accounting data into a single scorecard.  
					See the health and wealth of your business on one screen.<hr>
					</div>
				</div>
				<div class="row-fluid">
					<div class="span8 ">
						<div class="row-fluid">
							<div class="page-strip-subheading" >As simple as 123.</div>
						</div>
						<div class="row-fluid">
							Have immediate access to your latest business numbers from anywhere. 
							We make everything simple and ready to view.  Margin Mentor uploads all your 
							accounting information into our analytic back-end  and produces powerful visializations 
							of your business so that you get the full picture.
						</div>
						<div class="row-fluid">	
							<div class="span7">
								<ul>
									<li>All data transmissions are encrypted.</li>
									<li>Hosted in a secure environment.</li>														
								</ul>						
								<div class="span3" style="margin-left: 0px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-green.png"/></a></div>					
							</div>							
							<div class="span5" style="padding-top: 20px;">
								<img src="http://marginmentor.co.za/wp-content/uploads/why-2.jpg"/>
							</div>
							
						</div>
					</div>
					<div class="span4 "><img src="http://marginmentor.co.za/wp-content/uploads/why-1.jpg"/></div>
				</div>
				
			</div>
			
			<div class="row-fluid info-content-strip strip-2">
				<div class="span5 "><img src="http://marginmentor.co.za/wp-content/uploads/why-3.jpg"/></div>
				<div class="span7 " style="margin-top: 40px;">
					<div class="row-fluid">
						<div class="page-strip-subheading" >Become financially literate</div>
					</div>	
					<div class="row-fluid">
						No finance qualification is needed. Our short course will give you the ability to know which 
						numbers are the most critical to the health of your business and derserve your keen attention.
					</div>
					<div class="row-fluid">						
						<div class="span2" style="margin-left: 0px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-green.png"/></a></div>					
					</div>
				</div>
					
			</div>	
			
			<div class="row-fluid info-content-strip strip-3">
				<div class="row-fluid">
					<div class="span7" style="margin-top: 40px;">
						<div class="row-fluid">
							<div class="page-strip-subheading" >Pictures tell the story</div>
						</div>	
						<div class="row-fluid">
							Margin Mentor's poweful financial visualizations of your  performance, help you 
							track the important profitablity trends over time.  Providing you with quick visual 
							portraits of your business' health and wealth. With drillable features just a few clicks 
							gets you to the detail of a specific financial indicator.							
						</div>						
						<div class="span2" style="margin-left: 0px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-green.png"/></a></div>					
					</div>
					<div class="span5 " style="margin-top: -20px;">
						<img src="http://marginmentor.co.za/wp-content/uploads/why-4.jpg"/>
					</div>
				</div>
			</div>	
			
			<div class="row-fluid info-content-strip strip-4">
				<div class="span5 ">
					<img src="http://marginmentor.co.za/wp-content/uploads/why-5.jpg"/>					
				</div>
				<div class="span7" style="margin-top: 30px;">
					<div class="row-fluid">
						<div class="page-strip-subheading" >Gain deep and valuable insights</div>
					</div>	
					<div class="row-fluid">
						Margin Mentor provides a structured framework to construct and analyse your financial statements 
						and provide actionable insights.  Converting accounting data into powerful pictutres. Allowing you 
						to make better desicions.												
					</div>
					<div class="span2" style="margin-left: 0px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-green.png"/></a></div>					
			
				</div>
					
			</div>
			
			<div class="row-fluid info-content-strip strip-5">
				<div class="row-fluid">
					<div class="span7" style="margin-top: 40px;">
						<div class="row-fluid">
							<div class="page-strip-subheading" >Create your wealth</div>
						</div>	
						<div class="row-fluid">
							Unlock your wealth creation potential  through securing control of your company&#39;s 
							future by effectivley diagnosing problems and profit drains early, and increasing profitability and sustainability.
						</div>						
						<div class="span2" style="margin-left: 0px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-green.png"/></a></div>					
					</div>
					<div class="span5 "><img src="http://marginmentor.co.za/wp-content/uploads/why-6.jpg"/></div>
				</div>
			</div>		
		</div>
	</div>