<div id="content">
	<div class="row-fluid info-content-strip  strip-1" style="height: 540px; padding-top: 65px;">
		<div class="row-fluid page-top-heading">
			<div class="span12">See a clear picture of the financial health of your business instantly</div>
		</div>
		<div class="row" style="height: 214px;"> 
			<div class="row span5">
				<img style="margin:2% auto 0 64%;" src="http://marginmentor.co.za/wp-content/uploads/visualization-1.jpg"/>
			</div>
		</div>
		<div class="row-fluid">
			Margin Mentors turns your financial numbers into pictures.  These poweful visualizations clarify and 
			simplify the complex financial data so you can get  a clear view of your performance. They inspire action 
			and makes it easy to see the story your financial data is telling. Our powerful charts and graphs will help 
			you identify areas of  concern and provide an interpretive overview of the financial health of you business.		
		</div>
		<div class="row-fluid" style="padding: 0 0 0 160px; margin-top: 20px">
			<i>"The purpose of <b>visualization</b> is insight, not pictures"</i>
			
		</div>	
		<div class="row-fluid" style="padding: 0 0 0 330px; margin-top: 10px">
			Ben Shneiderman (1999)
			
		</div>			
		<div class="row-fluid" style="padding: 0 0 0 0; margin-top: 20px">
			Data by itself is invisable. In order to be able to see and sense of data, you need to visualize it. This is what we do!			
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-2" style="height: 230px">
		<div class="row-fluid right-content-left-offset">
			<div class="span4 left-offset">
				Plus our on-line tutorial How to Interpret your Statement of Comprehensive Income
			</div>
		</div>	
		<div class="row-fluid">
			<div class="page-strip-subheading" >See your profitability</div>
		</div>
		<div class="row-fluid">
			<div class="span7">			
				<div class="row-fluid">
					Margin Mentor will construct you statement of comprehensive income. This finanial statement, detailing revenue and 
					costs, is a key component of financial management and its primary objective to report how much money your  business 
					has made or lost during a specific period of time and is a useful tool for understanding the health of your business,
					 provding insights into how effectively you are controlling costs, how much is being spent on the operations in running the business.
				</div>			
			</div>
			<div class="span5" style="margin-top:-60px;"><img src="http://marginmentor.co.za/wp-content/uploads/visualization-2.jpg"/></div>			
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-3" style="height: 250px">
		<div class="row-fluid right-content-left-offset">
			<div class="span4 left-offset" style="top: 70px;">
				Plus our on-line tutorial How to Interpret your Statement of Financial Position
			</div>
		</div>	
		
		<div class="row-fluid">
			<div class="span5" ><img src="http://marginmentor.co.za/wp-content/uploads/visualization-3.jpg"/></div>			
			<div class="span7">
				<div class="row-fluid" style="margin-top:40px;">
					<div class="page-strip-subheading" >See your real worth</div>
				</div>				
				<div class="row-fluid">
					The statement of financial position (Balance Sheet) that we  construct, tells you how much money your 
					company has, how much it owes, and what is left for you as a shareholder.
				</div>			
			</div>						
		</div>
	</div>	
	
	<div class="row-fluid info-content-strip  strip-4" style="height: 230px">
		<div class="row-fluid right-content-left-offset">
			<div class="span4 left-offset" style="top: 65px;">
				Plus our on-line tutorial How to Interpret your Statement of Cash Flows
			</div>
		</div>	
		<div class="row-fluid">
			<div class="page-strip-subheading" >See where your money was spent</div>
		</div>
		<div class="row-fluid">
			<div class="span7">			
				<div class="row-fluid">
					Margin Mentor will automatically generate your statement of Cash Flows. Here you will be able to see 
					the operating activity of your business and provides insight into its ability to generate cash. It will 
					disclose how your company raised money and how it spent those funds during a given period.  Use the your
					 statement of cash flows to make financing, operating, and investing decisions. 
				</div>			
			</div>
			<div class="span5" style="margin-top:-45px;"><img src="http://marginmentor.co.za/wp-content/uploads/visualization-4.jpg"/></div>			
		</div>		
	</div>	
	
	<div class="row-fluid info-content-strip  strip-5" style="height: 220px">			
		<div class="row-fluid right-content-left-offset">
			<div class="span4 left-offset" style="top: 80px; padding-top:18px; padding-left: 20px">
				Plus our on-line Financial Raios tutorial
			</div>
		</div>	
		
		<div class="row-fluid">
			<div class="span5" ><img src="http://marginmentor.co.za/wp-content/uploads/visualization-5.jpg"/></div>			
			<div class="span7">
				<div class="row-fluid">
					<div class="page-strip-subheading" >Analyze your numbers</div>
				</div>				
				<div class="row-fluid">
					Our financial scorecard is a strategic financial performance management tool, that calculates and monitors
					 key financial ratios for your company. It articulates the links between leading inputs (human and physical),
					  processes, and lagging outcomes (financial performance) and focuses on the importance of managing these components
					   to achieve the company&#39;s strategic priorities.
				</div>			
			</div>						
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-6" style="height: 600px; margin-left: -220px; margin-bottom:50px; width: 930px;">		
		<div class="row-fluid" >
			<div class="page-strip-subheading" >View a snapshot of your numbers</div>
		</div>
		<div class="row-fluid">
			The dashboard gives you a visual display of the most important financial information needed to achieve your profitability 
			objectives. It fits entirely on a single computer screen so you can monitor it at a glance.
		</div>			
			
		<div class="row-fluid">		
			<div class="magnify span12">
				
				<!-- This is the magnifying glass which will contain the original/large version -->
				<div class="large"></div>
				
				<!-- This is the small image -->
				<img class="small" src="//marginmentor.co.za/wp-content/uploads/visualization-6.jpg"/>				
			</div>			
		</div>								
	</div>	
</div>