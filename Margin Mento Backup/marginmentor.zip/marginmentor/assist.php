<div id="content">
	<div class="row-fluid info-content-strip  strip-1" style="height: 360px; padding-top: 65px;">
		<div class="row-fluid page-top-heading">
			<div class="span12">Your dedicated advisor who will visit your company every month for 12 months.</div>
		</div>
		<div class="row-fluid">
			<div class="span6" style="margin-top: 40px;">
				<div class="row-fluid">
					<div class="page-strip-subheading" >A dedicated advisor</div>
				</div>	
				<div class="row-fluid">
					Our  Margin Mentor SME advisors are highly trained business development specialists. The primary role of our advisors include:
				</div>						
			</div>
			<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/assist-1.jpg" alt="Some image"/></div>
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-2" style="height: 180px">
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/assist-2.jpg"/></div>
		<div class="span6" style="margin-top: 40px">			
			<div class="row-fluid">
				Software systems registartion at your business location, device configuration and seting up 
				communications integration with the Margin Mentor server
			</div>			
		</div>			
	</div>
	
	<div class="row-fluid info-content-strip  strip-3" style="height: 150px">		
		<div class="span6" style="margin-top: 30px">			
			<div class="row-fluid">
				Customization of the financial data upload template by mapping of your general ledger account 
				codes and verification of the integrity of the data on a monthly basis
			</div>			
		</div>
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/assist-3.jpg"/></div>
	</div>	
	
	<div class="row-fluid info-content-strip  strip-4" style="height: 150px">
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/assist-4.jpg"/></div>		
		<div class="span6" style="margin-top: 40px">			
			<div class="row-fluid">
				Comprehensive on-site user first-time and on-going training for the SME owner and accounting 
				personnel on the software application use.
			</div>			
		</div>			
	</div>	
	
	<div class="row-fluid info-content-strip  strip-5" style="height: 260px">			
		<div class="span6" style="margin-top: 80px">			
			<div class="row-fluid">
				Conduct the software-based Business Diagnostic Assessment and engage in improvement dialogue. 
			</div>			
		</div>	
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/assist-5.jpg"/></div>			
	</div>
	
	<div class="row-fluid info-content-strip  strip-6" style="height: 260px">
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/assist-6.jpg"/></div>			
		<div class="span6" style="margin-top: 80px">			
			<div class="row-fluid">
				Conduct the software-based SME Fundability Assessment and engage in improvement strategies.
			</div>			
		</div>						
	</div>
	
	<div class="row-fluid info-content-strip  strip-7" style="height: 180px">			
		<div class="span6" style="margin-top: 40px">			
			<div class="row-fluid">
				Advise and facilitate the SME funding application to appropriate lenders if finance is a need. 
			</div>			
		</div>	
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/assist-7.jpg"/></div>			
	</div>
	
	<div class="row-fluid info-content-strip  strip-8" style="height: 290px">
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/assist-8.jpg"/></div>			
		<div class="span6" style="margin-top: 60px">			
			<div class="row-fluid">
				Our MarginAssit service has its operational limits and the best expectation of our advisor is that
				 they are someone who can be consulted from time to time, when challenges arise that are new and unknown
			</div>			
		</div>						
	</div>
</div>