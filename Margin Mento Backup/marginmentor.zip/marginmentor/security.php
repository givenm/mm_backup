	
		<div class="row-fluid info-content">
			<div class="row-fluid info-content-strip strip-1" style="height: 340px; margin-top:50px;">				
				<div class="row-fluid">
					<div class="span7">
						<div class="row-fluid page-top-heading">
							<div class="span12">Bank-level security</div>
						</div>
						<p>We employ multiple layers of security and protection  to safeguard you and your financial information.  Margin Mentor 
						uses 256 - bit SSL encryption security while our practises are monitored and verified by VeriSign.
						</p>												
					</div>					
				
					<div class="span5">
						<img src="http://marginmentor.co.za/wp-content/uploads/security-1.jpg"/>
					</div>
				</div>				
			</div>
			
			<div class="row-fluid info-content-strip strip-1" style="padding-top:0; margin-top: -40px;">
				<div class="span4">
					<div class="row-fluid">
						<div class="span4">
							<img style="margin-top:32px;" src="http://marginmentor.co.za/wp-content/uploads/security-1-1.jpg" />
						</div>
						<div class="span7" style="margin-left: 23px;">
							<div class="row page-strip-subheading" style="font-size:16px; line-height: 22px; margin-bottom: 7px;">
								Data is encrypted from Login to Logout
							</div>
							<div class="row">
								No one can see your  personal information. Not even Margin Mentor employees.
							</div>
						</div>
					</div>
				</div>
				<div class="span4">
					<div class="row-fluid">
						<div class="span4">
							<img style="margin-top:39px;" src="http://marginmentor.co.za/wp-content/uploads/security-1-2.jpg" />
						</div>
						<div class="span7" style="margin-left: 23px;">
							<div class="row page-strip-subheading" style="font-size:16px; line-height: 22px; margin-bottom: 7px;">
								No one can access or move your money
							</div>
							<div class="row">
								Margin Mentor is a "read-only" service. No one can withdraw funds or transfer money - not even you.
							</div>
						</div>
					</div>
				</div>
				<div class="span4">
					<div class="row-fluid">
						<div class="span4">
							<img style="margin-top:60px; margin-left: -7px;" src="http://marginmentor.co.za/wp-content/uploads/security-1-3.jpg" />
						</div>
						<div class="span7" style="margin-left: 23px;">
							<div class="row page-strip-subheading" style="font-size:16px;">
								Independent <br>Verification
							</div>
							<div class="row">
								VeriSign verifies our security practises constantly.
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row-fluid info-content-strip">
				<div class="row-fluid" style="border-top:1px solid #e5e5e5; height: 55px; padding-top:13px;">
					<div class="page-strip-subheading" >More on Security</div>
				</div>
				<div class="row-fluid" style="border-top:1px solid #e5e5e5; height: 38px; padding-top:10px;">
					Our Layers of Security and how we guarantee them.
				</div>
				<div class="accordion" id="accordion2" style="margin-left:0px; width: 940px">
		                	<div class="accordion-group" style="border: none; border-top:1px solid #e5e5e5; border-radius:0;">
						<div class="accordion-heading">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
								+ Authentication
							</a>
						</div>
						<div id="collapseOne" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="span8">
									<p>
										Authentication is the process of verifying that the users of our application are who they say they are. 
										This is like checking for somebody&#39;s ID. We shall implement this by requiring user to use usernames and 
										password. The password will be encrypted with 256-bit and scrambled with what is known as salting  and will 
										only be known by the owners.
									</p>
									<p>
										Even Margin Mentor wont know the user&#39;s  password. We shall only be able to reset it if the owner forgets 
										it. In the unlikely event of someone steeling our database password files, it will be useless. 
									</p>
									<p>
										Passwords will have expiry date to force users to change passwords frequently.
									</p>
								</div>
								<div class="span4">
									<img style="margin-left:135px;" src="http://marginmentor.co.za/wp-content/uploads/security-2.jpg"/>
								</div>
							</div>
						</div>
			                </div>
			                <div class="accordion-group" style="border: none; border-top:1px solid #e5e5e5; border-radius:0;">
						<div class="accordion-heading">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
							+ Authorization
							</a>
						</div>
						<div id="collapseTwo" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="span8">
									<p>
										When a user is authenticated, that only means that the user is known to the system and has been recognized
										 by it. It doesn’t mean that the user is free to do whatever he or  she wants in the system. The next logical
										  step in securing an application is to determine which actions that user is allowed to perform, and which 
										  resources she has access to, and make sure that if the user doesn’t have the proper permissions he or she 
										  cannot carry out that particular action. This is the work of the authorisation process. 
									</p>
									<p>
										We shall ensure that every use is given a role to represent the authority they have once they are logged into 
										the system.
									</p>
								</div>
								<div class="span4">
									<img style="margin-left:146px;" src="http://marginmentor.co.za/wp-content/uploads/security-3.jpg"/>
								</div>
							</div>
						</div>
			                </div>
			                <div class="accordion-group" style="border: none; border-top:1px solid #e5e5e5; border-radius:0;">
						<div class="accordion-heading">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
								+ Data Integrity
							</a>
						</div>
						<div id="collapseThree" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="span8">
									<p>
										Data sent by a valid user shouldn’t be altered by a third entity on its way to  the server, or in its storage. 
										This is what Data integrity is all about. 
									</p>
									<p>
										In the application we shall  accomplish this through the use of one-way cryptographic algorithms that make it
										 almost impossible to alter an input and produce a corrupted message whose encrypted hash is the same as the
										  original message (thus deceiving the receiver into thinking it is valid). Communication will be over an 
										  encrypted channel using SSL security protocol.
									</p>
								</div>
								<div class="span4">
									<img style="margin-left:88px;" src="http://marginmentor.co.za/wp-content/uploads/security-4.jpg"/>
								</div>
							</div>
						</div>
			                </div>
			                
			                <div class="accordion-group" style="border: none; border-top:1px solid #e5e5e5; border-radius:0;">
						<div class="accordion-heading">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseFour">
								+ Confidentiality
							</a>
						</div>
						<div id="collapseFour" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="span8">
									<p>
										Potentially sensitive information belonging to one user, or group of users, should be accessible only to this
										 user or group. This is Data confidentiality,  Encryption algorithms are the main helper in achieving this goal
										  and all communication to the margin mentor server will be through https: Authorisation, will ensure that information 
										  is made available only to users who are authorized to access it. This ensures that only authorized users can 
										  view sensitive data.
									</p>	
								</div>
								<div class="span4">
									<img style="margin-left:83px;" src="http://marginmentor.co.za/wp-content/uploads/security-5.jpg"/>
								</div>					
							</div>
						</div>
			                </div>
			                
			                <div class="accordion-group" style="border: none; border-top:1px solid #e5e5e5; border-radius:0;">
						<div class="accordion-heading">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseFive">
								+ Non-Repudiation
							</a>
						</div>
						<div id="collapseFive" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="span8">
									<p>
										The means used to prove that a user performed some action such that the user cannot reasonably deny having done so. 
										This ensures that transactions can be proven to have happened. The use of tokens and certificates created during the 
										authentication process will ensure that users are tied to the login and the auditing in point 7 will also 
										aid with this.
									</p>
								</div>
								<div class="span4">
									<img style="margin-left:131px;" src="http://marginmentor.co.za/wp-content/uploads/security-6.jpg"/>
								</div>
							</div>
						</div>
			                </div>
			                
			                <div class="accordion-group" style="border: none; border-top:1px solid #e5e5e5; border-radius:0;">
						<div class="accordion-heading">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseSix">
								+ Quality of Service
							</a>
						</div>
						<div id="collapseSix" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="span8">
									<p>
										The means used to prove that a user performed some action such that the user cannot reasonably deny having.
										 This is a security issue because if the service is not available to users , then is it useless. 
										 The Architecture of our application is such that we shall easily scale it at cloud scale to ensure that 
										 as we add more users or as traffic spike, individual users will continue to have the same experience they had from 
										 day one
									</p>
								</div>
								<div class="span4">
									<img style="margin-left:66px;" src="http://marginmentor.co.za/wp-content/uploads/security-7.jpg"/>
								</div>
							</div>
						</div>
			                </div>
			                
			                <div class="accordion-group" style="border: none; border-top:1px solid #e5e5e5; border-radius:0;">
						<div class="accordion-heading">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseSeven">
								+ Auditing
							</a>
						</div>
						<div id="collapseSeven" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="span8">
									<p>
										The means used to capture a tamper-resistant record of security related events for the purpose of
										 being able to evaluate the effectiveness of security policies and mechanisms. To enable this, our  
										 system will maintain a record of transactions and security information, including activities 
										 performed by each logged in user.
									</p>
								</div>
								<div class="span4">
									<img style="margin-left:69px;" src="http://marginmentor.co.za/wp-content/uploads/security-8.jpg"/>
								</div>
							</div>
						</div>
			                </div>			               
			                
			                <div class="accordion-group" style="border: none; border-top:1px solid #e5e5e5; border-bottom:1px solid #e5e5e5; border-radius:0;">
						<div class="accordion-heading">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseEight">
								+ Security and Privacy Procedures
							</a>
						</div>
						<div id="collapseEight" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="span8">
									<p>
										<a class="inline-security-links" style="color: rgb(2, 2, 255);" href="//marginmentor.co.za/terms-of-use/" >Terms of use</a>
									</p>
									<p>
										<a class="inline-security-links" style="color: rgb(2, 2, 255);" href="//marginmentor.co.za/privacy-and-security-policy">Security and Privacy Policy</a>
									</p>									
								</div>
								<div class="span4">
									<img style="margin-left:114px; margin-top: 14px;" src="http://marginmentor.co.za/wp-content/uploads/security-9.jpg"/>
								</div>
							</div>
						</div>
			                </div>
				</div>
			</div>			
		</div>
</div>