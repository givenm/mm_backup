<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Margin Mentor
 */

get_header(); ?>
	
	<?php
		if (is_page('what-is-margin-mentor')){

			get_template_part('what-is-margin-mentor');

		}else if (is_page('why-margin-mentor')){

			get_template_part('why-margin-mentor');

		}else if(is_page('how-it-works')){

			get_template_part('how-it-works');

		}else if(is_page('security')){

			get_template_part('security');

		}else if(is_page('pricing')){

			get_template_part('pricing');
			
		} 

		else if(is_page('education')){

			get_template_part('education');

		} else if(is_page('overview')){

			get_template_part('overview');

		} else if(is_page('business-etools')){

			get_template_part('business-etools');

		} else if(is_page('assist')){

			get_template_part('assist');

		} else if(is_page('visualization')){

			get_template_part('visualization');

		}
	
	?>

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); 		
			the_content(); /*this allows the pages content to be displayed. The content is NOT from a custom get_template_part() method*/
		endwhile; else: ?>
			<p>Sorry, no page called criteria.</p>
	<?php endif; ?>

<?php get_footer(); ?>

<script type="text/javascript">
	/*The menu ids being used are generated in the functions.php where the menu is created.
	The values being used in is_page() function are the slug values of pages created*/
	<?php if (is_page('what-is-margin-mentor')): ?>
		$('#menu1').addClass('active-menu');
	<?php endif ?>
	
	<?php if (is_page('why-margin-mentor')): ?>
		$('#menu2').addClass('active-menu');		
	<?php endif ?>
	
	<?php if (is_page('how-it-works')): ?>
		$('#menu3').addClass('active-menu');
	<?php endif ?>
	
	<?php if (is_page('security')): ?>
		$('#menu4').addClass('active-menu');
	<?php endif ?>

	<?php if (is_page('pricing')): ?>
	
		$('#menu5').addClass('active-menu');
	<?php endif ?>
	
</script>
		