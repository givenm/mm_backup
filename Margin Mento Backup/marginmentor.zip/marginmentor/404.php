<?php get_header(); ?>
<div class="row-fluid main-content-container">
	<div class="row-fluid span8 offset2 main-content">		
		<h2>Error 404 - Sorry! The page you are looking for doesn't exist</h2>		
	</div>
</div>

<?php get_footer(); ?>