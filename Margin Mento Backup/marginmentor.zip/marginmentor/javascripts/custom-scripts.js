$(document).ready(function() {
	 
	 

	/*Menu on home page*/
	$('#sdt_menu li').mouseenter(function(){		
		var $elem = $(this);

		$elem.find('img')
			 .stop(true)
			 .animate({
				'width':'110px',
				'height':'70px',
				'left':'0px' 		//properties for the picture popup
			 },550,'easeOutBounce')
			 .addBack()
			 .find('.sdt_wrap')
		     .stop(true)
			 .animate({'top':'90px'},480,'easeOutBounce') //text dropping down
			 .addBack()
			 .find('.sdt_active')
		     .stop(true)
			 .animate({'height':'78px'},400,function(){ //height of the bottom drop down div
				var $sub_menu = $elem.find('.sdt_box');
				if($sub_menu.length){ /*The sub menu position*/
					var left = '110px';
					if($elem.parent().children().length == $elem.index()+1)
						left = '-110px';
					$sub_menu.show().animate({'left':left},400);
				}	
			});
		}).mouseleave(function(){
			var $elem = $(this);
			var $sub_menu = $elem.find('.sdt_box');
			if($sub_menu.length)
				$sub_menu.hide().css('left','0px');
			
			$elem.find('.sdt_active')
				 .stop(true)
				 .animate({'height':'0px'},400)
				 .addBack().find('img')
				 .stop(true)
				 .animate({
					'width':'0px',
					'height':'0px',
					'left':'50px'},300)
				 .addBack()
				 .find('.sdt_wrap')
				 .stop(true)
				 .animate({'top':'25px'},500);
		});            
	
	/*end of menu on home page*/	
	
	
	/*Animate to top on footer*/
	$('.back-to-top').click(function() {
		$('html, body').animate({
			scrollTop : 0
		}, 1000);
	});
	/*End: Animate to top on footer*/
	
        
        /*Side menu on how it works page*/
	var previousItem;
	
        
	$('.side-menuitem').click(function(){
			
		clickedItem = $(this);
		id = clickedItem.attr('id');
		clickedItem.attr('id', '');
		window.location.hash = id;
		clickedItem.attr('id', id);	
		                    
		previousItem.find('.ajaxloader').animate({'opacity': '0'}, 500); //hiding the ajaxloading gif
		if(!clickedItem.hasClass('omni-current')){ //check if the clicked menu item is active and prevent reloading page if it's active
			
		        //activative the clicked menuitem                   			
			clickedItem.addClass('omni-current');
			clickedItem.find('.ajaxloader').animate({'opacity': '5'}, 300); //showing the ajaxloading gif
			clickedItem.find('.pointer-image').show();
	        
	        
		        //deactivative the previously active menuitem			
			previousItem.removeClass('omni-current');
			previousItem.find('.pointer-image').hide(); 
			previousItem = clickedItem;				
		        
		        
		        /*Load pages with AJAX*/
		        $(".right-content").load(clickedItem.find('.side-menuitem-link').text() + ' #content', function(){
		        	clickedItem.find('.ajaxloader').animate({'opacity': '0'}, 500); //hiding the ajaxloading gif
				$('#content').css('opacity', '0');
		        	$(".right-content").animate({'height': $('#content').height() + "px"}, 500);
		        	$('#content').animate({'opacity': '1'}, 700);
		        });
		        
		} 
	});
	
	       
        if(window.location.hash){      //if hash then reopen the last opened menu before the refresh of page else just open overview  
		hash = window.location.hash;		
		if(hash != '#one' && hash != '#two' && hash != '#three' && hash != '#four'){
			previousItem = $(window.location.hash);	
		}
						
	}else{
		previousItem = $('.side-menuitem').first(); 
		
	}
	document.body.scrollTop = 0;
	
	//activative the previously active menuitem after a refresh 
	previousItem.addClass('omni-current');
	previousItem.find('.ajaxloader').animate({'opacity': '5'}, 300); //showing the ajaxloading gif
	previousItem.find('.pointer-image').show(); //show the pointer
	
	 /*Load pages with AJAX*/
        $(".right-content").load(previousItem.find('.side-menuitem-link').text() + ' #content', function(){
        	previousItem.find('.ajaxloader').animate({'opacity': '0'}, 500); //hiding the ajaxloading gif
		$('#content').css('opacity', '0');
        	$(".right-content").animate({'height': $('#content').height() + "px"}, 500);
        	$('#content').animate({'opacity': '1'}, 700);
        });
        
   	/*End: side menu js*/           
             
        
        document.onclick = function (evt) {  //prevent scrolltop of page when changing the hash in url
	    var tgt = (evt && evt.target) || event.srcElement,
	        scr = document.body.scrollTop;
	
	    if (tgt.tagName == "A" && tgt.href.slice(-1) == "#") {
	        window.location.href = "#";
	        document.body.scrollTop = scr;           
	        return false;
	    }
	}
	
	/**Pricing page*/		
	$('.features').hover(
	function(){
		$(this).find('.grey-sample-arrow').hide();
		$(this).find('.blue-sample-arrow').show();
	},
	function(){
		$(this).find('.grey-sample-arrow').show();
		$(this).find('.blue-sample-arrow').hide();
	}
	);
	
	var current_feature = "0";
	$('.features').click(function(){
		$('.plan').attr('id', '');
		$(this).parents().find('.' + $(this).attr('banner')).attr('id', 'most-popular');
		$('#myTab li:eq(' + $(this).find('.feature-tab-num').val() + ') a').tab('show'); // Select third tab (0-indexed)
				
		if(current_feature !== $(this).find('.feature-tab-num').val()){
			$('#myTab li:eq(' + $(this).find('.feature-tab-num').val() + ') a').css({'padding-top' : '8px', 'padding-bottom' : '8px'});
			$('#myTab li:eq(' + current_feature  + ') a').css({'padding-top' : '0', 'padding-bottom' : '0'});
		}
		
		$('#myTab li:eq(' + current_feature + ')').find('img').css('display', 'none');

		$('#myTab li:eq(' + $(this).find('.feature-tab-num').val() + ')').find('img').css('display', 'block');
		
		current_feature  = $(this).find('.feature-tab-num').val();
		
		$('html, body').animate({
		        scrollTop: $(".pricing-tab-container").offset().top - 80
		}, 1000);
	});
	/*End of pricing page*/
		
		
		
	
	var native_width = 0;
	var native_height = 0;

	//Now the mousemove function
	
	$( document ).on( "mousemove", ".magnify", function(e) {	 		
		//When the user hovers on the image, the script will first calculate
		//the native dimensions if they don't exist. Only after the native dimensions
		//are available, the script will show the zoomed version.
		if(!native_width && !native_height)
		{			
			//This will create a new image object with the same image as that in .small
			//We cannot directly get the dimensions from .small because of the 
			//width specified to 200px in the html. To get the actual dimensions we have
			//created this image object.
			var image_object = new Image();
			image_object.src = $(".small").attr("src");
			
			//This code is wrapped in the .load function which is important.
			//width and height of the object would return 0 if accessed before 
			//the image gets loaded.
			native_width = image_object.width;
			native_height = image_object.height;			
		}
		else
		{
			//x/y coordinates of the mouse
			//This is the position of .magnify with respect to the document.
			var magnify_offset = $(this).offset();
			//We will deduct the positions of .magnify from the mouse positions with
			//respect to the document to get the mouse positions with respect to the 
			//container(.magnify)
			var mx = e.pageX - magnify_offset.left;
			var my = e.pageY - magnify_offset.top;
			
			//Finally the code to fade out the glass if the mouse is outside the container
			if(mx < $(this).width() && my < $(this).height() && mx > 0 && my > 0)
			{
				$(".large").fadeIn(100);
				
			}
			else
			{
				$(".large").fadeOut(100);
			}
			if($(".large").is(":visible"))
			{
				//The background position of .large will be changed according to the position
				//of the mouse over the .small image. So we will get the ratio of the pixel
				//under the mouse pointer with respect to the image and use that to position the 
				//large image inside the magnifying glass
				var rx = Math.round(mx/$(".small").width()*native_width - $(".large").width()/2)*-1;
				var ry = Math.round(my/$(".small").height()*native_height - $(".large").height()/2)*-1;
				var bgp = rx + "px " + ry + "px";
				
				//Time to move the magnifying glass with the mouse
				var px = mx - $(".large").width()/2;
				var py = my - $(".large").height()/2;
				//Now the glass moves with the mouse
				//The logic is to deduct half of the glass's width and height from the 
				//mouse coordinates to place it with its center at the mouse coordinates
				
				//If you hover on the image now, you should see the magnifying glass in action
				$(".large").css({left: px, top: py, backgroundPosition: bgp});
			}
		}	
	});
});