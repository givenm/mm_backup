		
		<div class="row-fluid info-content">			
			<div class="row-fluid info-content-strip strip-1" style="margin-top:60px; margin-bottom: 10px;">
				<div class="row-fluid page-top-heading">
					<div class="span12">A Platform for profit</div>
				</div>				
				<div class="row-fluid">
					<div class="span12">
					<div>Margin Mentor is an SME Platform for Profitability which is a holistic
					 entrepreneur development framework,</div> directed at small business owners, who generally lack
					  financial literacy, which inhibits their ability to build profitable and sustainable businesses.<hr>
					</div>
				</div>
				<div class="row-fluid">
					<div class="span7  ">
						<div class="row-fluid">
							<div class="page-strip-subheading" >Know your numbers</div>
						</div>
						<div class="row-fluid">
							At Margin Mentor we believe that successful and profitable businesses are a result of successful and 
							knowledgeable entrepreneurs. With our Platform for Profitability we aim to provide you the business owner with:
						</div>
						<div class="row-fluid">
							<ul>
								<li>A sound financial mangement <b>EDUCATION</b></li>
								<li>Insightful and powerful <b>VISUALIZATIONS</b> of your
								 company&#39;s performance</li>
								<li>Knowledge and financial intelligence to <b>MITIGATE</b> 
								against the risk of busiesss failure</li>								
							</ul>
							<div class="span2" style="margin-left: 1px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-orange.png"/></a></div>
							
						</div>
					</div>
					<div class="span5"><img src="//marginmentor.co.za/wp-content/uploads/what-1.jpg"/></div>
				</div>
				
			</div>
			
			<div class="row-fluid info-content-strip strip-2">				
				<div class="span4 "><img src="//marginmentor.co.za/wp-content/uploads/what-2.jpg"/></div>
				<div class="span8 ">
					<div class="row-fluid">
						<div class="page-strip-subheading">Toward Profitability and Sustainability</div>
					</div>	
					<div class="row-fluid">
						Go from survival to profitability and sustainability. We exist 
						to facilitate your transition from a survival SME to a thriving 
						and sustainable company. Where we define sustainable in the SME
						 context as a business displaying the characteristicsof being:
					</div>
					<div class="row-fluid">
						<div class="span3">
							<ul>
								<li>Relevant</li>
								<li>Structured</li>
								<li>Responsible</li>
								<li>Knowledgeable</li>
							</ul>
						</div>
						<div class="span9">
							<ul>
								<li>Able to  displaying some degree of economic wisdom</li>
								<li>Productive</li>
								<li>Profitable</li>
								<li>Competitive</li>
							</ul>
						</div>
						<div class="span2" style="margin-left: 1px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-orange.png"/></a></div>
					</div>
				</div>
					
			</div>	
			
			<div class="row-fluid info-content-strip strip-3">
				<div class="row-fluid">
					<div class="span8" style="padding-top:50px;">
						<div class="row-fluid">
							<div class="page-strip-subheading">Our strategic mandate</div>
						</div>	
						<div class="row-fluid">
							Margin Mentor has as its strategic deliverable, to be the ultimate entrepeneur development, 
							support and reporting apparatus, which actively enables small business owners to move their company&#39;s 
							from the difficult start-up, to the expansion phase of its growth. We view this as the ultimate 
							developmental destination for a small business, as it is only during this phase that the enterprise can deliver on the important
							expectation of creating decent jobs, contribute meaningfully to the GDP growth of the
							South African economy and start the process of accessing funding.							
						</div>	
						<div class="span2" style="margin-left: 1px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-orange.png"/></a></div>				 					
					</div>
					<div class="span4"><img src="//marginmentor.co.za/wp-content/uploads/what-3.jpg"/></div>
				</div>
				
			</div>
			
			<div class="row-fluid info-content-strip strip-4">
				<div class="span5"><img src="//marginmentor.co.za/wp-content/uploads/what-4.jpg"/></div>
				<div class="span7" style="padding-top:50px;">
					<div class="row-fluid">
						<div class="page-strip-subheading">Easy and intuitive</div>
					</div>	
					<div class="row-fluid">
						Doing all of this in a simple, intuitive, user-friendly manner that would allow 
						for rapid adoption by SMEs as ‘layman’s’ terminology and methodology would be an implementation imperative.									
					</div>	
					<div class="span2" style="margin-left: 0px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-orange.png"/></a></div>											
				</div>
					
			</div>
			
			<div class="row-fluid info-content-strip strip-5">
				<div class="row-fluid">
					<div class="span7" style="padding-top:80px;">
						<div class="row-fluid">
							<div class="page-strip-subheading">Trusted, secure and safe</div>
						</div>	
						<div class="row-fluid">
							Your information is always secure. It's because we use bank-level  security. Our 256-bit SSL encryption
							 is used to protect you and your comapny's financial information							
						</div>	
						<div class="span2" style="margin-left: 0px;"><a href="#"><img src="//marginmentor.co.za/wp-content/uploads/read-more-orange.png"/></a></div>					
					</div>
					<div class="span5" style="padding-left: 50px;"><img src="//marginmentor.co.za/wp-content/uploads/what-5.jpg"/></div>
				</div>
			</div>			
		</div>
		
	</div>
</div>