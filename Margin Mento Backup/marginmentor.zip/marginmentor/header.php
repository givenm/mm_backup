<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php bloginfo( 'name' ) ?></title>
		<link rel="icon" type="image/png" href="//marginmentor.co.za/wp-content/uploads/favicon.png" />
		<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' ) ?>/bootstrap/css/bootstrap.min.css">
		
		<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' ) ?>/stylesheets/menu.css">		 
			
		<?php if(is_home()):?>
			<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' )?>/stylesheets/home.css">
			<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' )?>/stylesheets/tabs.css">			
		<?php endif?>
		
		<?php if(is_page('pricing')):?>
			<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' )?>/stylesheets/tsc_pricingtables.css">						
		<?php endif?>

		<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' ) ?>/stylesheets/footer.css">				
		
		<!--[if gt IE 5.5]>
		<link rel="stylesheet" type="text/css" href="stylesheets/all-ie-only.css" />
		<![endif]-->
		
		<?php 
			/*load the slider and other pluins resources resources*/
			if(is_home()){
				wp_head();	
			}
		?>
	</head>
	<body class="">
		<div class="row-fluid menu-container">
		<div class="span4" style="display: none;"><?php get_search_form(); ?></div>
			<div class="container" style="position: relative; height: 72px; <?php if(!is_home()){ echo 'border-bottom: 2px solid #ccc;';} ?> background-color: #fff;">				
				<a href="<?php echo home_url() ?>" title="Home" >
					<div class="logo-container">				
					</div>

				</a>
				<?php
				if ( function_exists( clean_custom_menus() ) ) {
					clean_custom_menus();
				}					
				?>
			</div>
		</div>
		
		<?php
			if(!is_home()): ?>
			<div class="row main-content-container">
				<div class="row container" style="background-color: white; height:auto">
			
		<?php endif;?>
		
			