</div> <!-- This is a closinng div for the manin-content container -->

<div class="row-fluid footer" >
	<div class="back-to-top" style="background-image: url('http://marginmentor.co.za/wp-content/uploads/back-to-top.jpg');"></div>
	<div class="container footer-content">
		<div class="span4 footer-left">
			<h4>MARGIN MENTOR</h4>
			<p>
				<a href="/">HOME</a>
			</p>
			<p>
				<a href="/what-is-margin-mentor">WHAT IS MARGIN MENTOR?</a>
			</p>
			<p>
				<a href="/what-is-margin-mentor">WHY MARGIN MENTOR?</a>
			</p>
			<p>
				<a href="/security">SECURITY</a>
			</p>
			<p>
				<a href="/pricing">PRICING</a>
			</p>
		</div>
		<div class="span4 footer-middle">
			<h4>LEGAL</h4>
			<p>
				<a href="/terms-of-use/" >TERMS OF USE</a>
			</p>
			<p>
				<a href="/privacy-and-security-policy">PRIVACY POLICY</a>
			</p>
			<p>
				<a href="/security">SECURITY AND DATA</a>
			</p>
			<p>
				<a href="#myModal" role="button" data-toggle="modal">TERMS AND CONDITIONS</a>
			</p>
		</div>
		<div class="span4 footer-right">
			<h4>CONTACT US</h4>
			<p>
				FIND US
			</p>
			<p>
				<a href="#maginoFACEBOOK"><img src="<?php bloginfo('template_directory')?>/images/facebook.png" style="margin: -4px 0 0 0;"/> FACEBOOK</a>
			</p>
			<p>
				<a href="#maginoTWITTER"><img src="<?php bloginfo('template_directory')?>/images/twitter.png" /> TWITTER</a>
			</p>
			<p>
				<a href="#maginoGOOGLE-PLUS"><img src="<?php bloginfo('template_directory')?>/images/google-plus.png" style="height:17px;"/> GOOGLE +</a>
			</p>
		</div>
	</div>
	<div class="row-fluid span6 offset3 trademark">
		<a class="terms-of-service" href="#">Terms of Service</a>
		<a href="#">Privacy</a>
		<a href="/">&copy 2013 www.marginmentor.co.za</a>
	</div>
</div>

<!-- Modal -->
<div id="myModal" class="modal hide fade container" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="width: 940px;left: 38%;">
	<div class="modal-header" style="border: none">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
			×
		</button>
		<!-- <h3 id="myModalLabel">Modal header</h3>-->
	</div>
	<div class="modal-body" style="height: 300px;">
		<p>
			One fine body…
		</p>
	</div>	
</div>


<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/jquery-lib-1.10.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/custom-scripts.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/jquery.marquee.min.js"></script>