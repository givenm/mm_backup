		
		<div class="span3 sidebar-menu" style="margin:20px 0 0 0; z-index:300">
			<?php
				if ( function_exists( custom_how_it_works_menus() )) {
					custom_how_it_works_menus();
				}					
			?>
		</div>
		<div class="span9 right-content" style="margin:3px 0 50px 10px; height:0px; z-index:300"></div>
		
		
	</div> <!--Closing tag for container-->
</div> <!--Closing tag for main-content-container-->