<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Margin Mentor
 */
get_header();

?>

<div class="row-fluid slider-container" style="margin: 38px 0 0 0; height: 487px;">
	<div class="row-fluid">
		<?php if( function_exists( 'sliceshow_slideshow' ) ) { sliceshow_slideshow( 227); } ?>	
	</div>	
</div>
<div class="row-fluid ticker-container">
			<div class = "ticker-text marquee" >
				PROVIDING SMALL AND MEDIUM-SIZED ENTERPRISES (SMEs) WITH AN <strong>EDUCATION-CENTRIC, VISUAL</strong> FINANCIAL 
				PERFORMANCE MANAGEMENT FRAMEWORK THAT <strong>MITIGATES</strong> THE RISKS OF BUSINESS OWNERS’LACK OF FINANCIAL LITERACY   
				<img class="ticker-text-seperator" src="http://marginmentor.co.za/wp-content/uploads/ticker-text-seperater.png"/>
				DEMYSTIFIED, SIMPLIFIED AND MORE!
				<img class="ticker-text-seperator" src="http://marginmentor.co.za/wp-content/uploads/ticker-text-seperater.png"/> 
				EDUCATE   | VISUALIZE   | MITIGATE  |  ASSIST
				<img class="ticker-text-seperator" src="http://marginmentor.co.za/wp-content/uploads/ticker-text-seperater.png"/>
				ENABLING SMALL BUSINESS OWNERS TO KNOW THEIR NUMBERS     
				<img class="ticker-text-seperator" src="http://marginmentor.co.za/wp-content/uploads/ticker-text-seperater.png"/>
				PROFITABLE & SUSTAINABLE ENTERPRISES
				<img class="ticker-text-seperator" src="http://marginmentor.co.za/wp-content/uploads/ticker-text-seperater.png"/>
			</div>
</div>
<div class="row-fluid main-content-container " style="margin:0">	
	<div class="container">	
			<div class="row tabs-wrap visible-desktop">
				<div class="navigation row span10" style="width: 737px;">
					<div class="link-tab"  id="#one">
						<div class="span2 tab-menuitem first-menuitem link-active" style="width: 180px; margin: 0 0 0 0;">							
							<span class="tab-icon ">
								<img class="unpressed-icon-img" src="http://marginmentor.co.za/wp-content/uploads/education-blue.png"/>
								<img class="pressed-icon-img" style="display:block" src="http://marginmentor.co.za/wp-content/uploads/education-white.png"/>
							</span>
							<span class="tab-text">Education</span>
						</div>
					</div>
					<div  class="link-tab" id="#two">
						<div class="span2 tab-menuitem link-disabled" style="width: 180px; margin: 0 0 0 0;">														
							<span class="tab-icon ">
								<img class="unpressed-icon-img" style="display:block" src="http://marginmentor.co.za/wp-content/uploads/visualization-blue.png"/>
								<img class="pressed-icon-img" src="http://marginmentor.co.za/wp-content/uploads/visualization-white.png"/>
							</span>
							<span class="tab-text">Visualization</span>
						</div>
					</div>
					<div  class="link-tab" id="#three">
						<div class="span2 tab-menuitem link-disabled" style="width: 180px; margin: 0 0 0 0;">														
							<span class="tab-icon ">
								<img class="unpressed-icon-img" style="display:block" src="http://marginmentor.co.za/wp-content/uploads/mitigation-blue.png"/>
								<img class="pressed-icon-img" src="http://marginmentor.co.za/wp-content/uploads/mitigation-white.png"/>
							</span>
							<span class="tab-text">Mitigation</span>
						</div>
					</div>
					<div class="link-tab"  id="#four">
						<div class="span2 tab-menuitem link-disabled last-menuitem" style="width: 180px; margin: 0 0 0 0;">
							<span class="tab-icon ">
								<img class="unpressed-icon-img" style="display:block" src="http://marginmentor.co.za/wp-content/uploads/assist-blue.png"/>
								<img class="pressed-icon-img" src="http://marginmentor.co.za/wp-content/uploads/assist-white.png"/>
							</span>
							<span class="tab-text">Assist</span>
						</div>
					</div>
				</div>		
				
		
				<div class="focus-wrap row span11 " style="margin: 23px 0 0 0; width: 940px;">
					<div id="one" class="row focus-active">
						<div class="focus-wrap-text span6 ">
							<div class="row tab-text-top" style="margin-top: 30px;">
								<p style="width: 100%; line-height: 20px;">TEACHES YOU TO UNDERSTAND YOUR  FINANCIAL NUMBERS.</p>
								<p style="width: 130%">KNOW HOW AND WHICH NUMBERS TO MEASURE.</p>
							</div>
							<div class="row tab-text-bottom" style="margin-top: 30px">
								<p style="width: 99%">Margin Mentor  will allow you to desmystify the realm of 
								accounting. With our financial literacy program you will know which numbers are
								 the most critical to the health of your business 
								and deserve your keen attention. Our program is designed for the layman who has 
								not been schooled in accounting.</p>
								<p style="margin-left: -2px; width: 70px;">
									<a href="http://marginmentor.co.za/how-it-works/#Education">
										<img src="http://marginmentor.co.za/wp-content/uploads/read-more-home-button.jpg"/>
									</a>
								</p>
							</div>
						</div>
						<div class="focus-wrap-image span4" style="margin-left: 170px; margin-top: 30px;">
							<img src="http://marginmentor.co.za/wp-content/uploads/education-bottom-tab.png"/>
						</div>
					</div>
					<div id="two" class=" row focus-hide" >
						<div class="focus-wrap-text span6 ">
							<div class="row tab-text-top">
								<p style="width: 98%;">VIEW THE HEALTH & WEALTH OF YOUR BUSINESS ON ONE SCREEN.</p>
								<p style="width: 980%;">GET POWERFUL INSIGHTS INTO YOUR FINANCES.</p>
								<p style="width: 98%;">NEAR REAL-TIME UPDATING EVERY MONTH.</p>
							</div>
							<div class="row tab-text-bottom" style="width: 87%">
								<p>Margin Mentor  synchronizes with your exsisting accounting system 
								and then securely and automatically pulls all your financial data into our analytical system. 
								No accounting qualification is needed. Our software does all the work of 
								number crunching and constructs all the financial charts, scorecard, dashboard 
								and trends monthly. </p>
								<p>You don&#39;t have to lift a finger!</p>
								<p style="margin-left: -2px; width: 70px;">
									<a href="http://marginmentor.co.za/how-it-works/#Visualization">
										<img src="http://marginmentor.co.za/wp-content/uploads/read-more-home-button.jpg"/>
									</a>
								</p>
							</div>
						</div>
						<div class="focus-wrap-image span5" style="margin-left: 50px; margin-top: 30px;">
						<img src="http://marginmentor.co.za/wp-content/uploads/visualization-bottom-tab.jpg"/>
						</div>
					</div>
					<div id="three" class="row focus-hide">
						<div class="focus-wrap-text span6 ">
							<div class="row tab-text-top">
								<p>PROTECT  YOUR MARGINS AND PROFITS.</p>
								<p>COMPARE YOUR FINANCIAL PERFORMANCE  TO HISTORY.</p>
								<p>ASSESS YOUR RISK.</p>
							</div>
							<div class="row tab-text-bottom">
								<p>Not knowing your financial numbers can ruin your business. And 
								measurement of these numbers is what allows you to run your business intead of 
								your buisness ruining you! As a business owner YOU are responsible 
								for the health and wealth of your business not accountants.</p>
								<p>Unfortunaley this responsibility cannot be delegated.  
								Margin Mentor allows you to effectivley diagnose problems and profit drains early, 
								and increase the proftability and sustainability of your business.</p>								
							</div>
						</div>
						<div class="focus-wrap-image span5" style="margin-left: 60px;">
							<img src="http://marginmentor.co.za/wp-content/uploads/mitigation-bottom-tab.jpg"/>
						</div>
					</div>
					<div id="four" class="row focus-hide">
						<div class="focus-wrap-text span6 ">
							<div class="row tab-text-top">
								<p>A DEDICATED ADVISOR TO YOUR COMPANY.</p>
								<p>YES! A REAL LIVE PERSON.</p>
								<p>ASSISTING AND HOLDING YOUR HAND.</p>
							</div>
							<div class="row tab-text-bottom">
								<p style="margin-top: 30px;">
								We will provide for a fully trained dedicated Margin Mentor advisor to 
								visit your business every month for an entire 12 months.</p>
								<p>Responsibilties would include initial systems set-up, user -training, 
								general ledger account code mapping,  validating monthly financial data and subsequent uploads.</p>
								<p>Ensuring data accuracy and integrity is of utmost importance to us.</p>
								<p style="margin-left: -2px; width: 70px;">
									<a href="http://marginmentor.co.za/how-it-works/#Assist">
										<img src="http://marginmentor.co.za/wp-content/uploads/read-more-home-button.jpg"/>
									</a>
								</p>
							</div>
						</div>
						<div class="focus-wrap-image span5" style="margin-left: 50px; margin-top: 60px;">
							<img src="http://marginmentor.co.za/wp-content/uploads/assist-bottom-tab.jpg"/>
						</div>
					</div>
				</div>
			</div>
	</div>
</div>

	<?php get_footer(); ?>
	
<script type="text/javascript">	
	
	$(document).ready(function(e) {			
	
	
		/*Tabs*/
		$('.tab-menuitem').click(function() {				
			$('html, body').animate({
				scrollTop : $(".main-content-container").offset().top - 75 //this value excludes the header whichis fixed
			}, 1000);				
		});
		
			
		$('.focus-active').animate({'margin-left': '0%'}, 200); //show by animation, the active tab		
			                
	        $('.navigation .link-tab').click(function(){                    
			id = $(this).attr('id'); 
			                  
			if(!$( id ).hasClass('focus-active')){ //when not active
								
				$('.link-active').find('.pressed-icon-img').hide();
				$('.link-active').find('.unpressed-icon-img').show();
				$('.link-active').addClass('link-disabled')
				.removeClass('link-active'); //deactivating the previously active tab
				
				
				$(this).find('.tab-menuitem')
				.removeClass('link-disabled')
				.addClass('link-active')
				$('.link-active').find('.unpressed-icon-img').hide();
				$('.link-active').find('.pressed-icon-img').show(); //activating the link clicked
				
				
				
					
				$('.focus-active').animate({'margin-left': '-110%'}, 200, function(){
					$('.focus-active').addClass('focus-hide').removeClass('focus-active').css('margin-left', '100%');;                            
					$( id ).addClass('focus-active').removeClass('focus-hide').animate({'margin-left': '0%'}, 200);                            
				});					
				}
	        });	
               	
        	/*End Tabs*/
        	
        
	        /*marqee text*/	       
		
		/**
		 * Example of starting a plugin with options.
		 * I am just passing all the default options
		 * so you can just start the plugin using $('.marquee').marquee();
		*/
		var mq = $('.marquee').marquee({
			//speed in milliseconds of the marquee
			speed: 120000,
			//gap in pixels between the tickers
			gap: 0,
			//time in milliseconds before the marquee will start animating
			delayBeforeStart: 10,
			//'left' or 'right'
			direction: 'left',
			//true or false - should the marquee be duplicated to show an effect of continues flow
			duplicated: true,
			//on hover pause the marquee - using jQuery plugin https://github.com/tobia/Pause
			pauseOnHover: true,
			//on cycle pause the marquee
			pauseOnCycle: false
		});				
		
		/*End of marqee text*/
	
	});
	
</script>