<div class="menu row-fluid span6 offset3 visible-desktop">
	<a href="<?php home_url() ?>">
		<div class="menuitem span4" style="margin:0;">
			<div id="home" class="menu-text">
				What is Margin Mentor?
			</div>
			<div class="menu-bottom-slide"></div>
			<img class="menu-image-large" src="<?php bloginfo( 'template_directory' ) ?>/images/1.jpg"/>
		</div> </a>

	<a href="#myModal" role="button" data-toggle="modal">
		<div class="menuitem span4" style="margin:0;">
			<div id="tour" class="menu-text">
				Why Margin Mentor?
			</div>
			<div class="menu-bottom-slide"></div>
			<img class="menu-image-large" src="<?php bloginfo( 'template_directory' ) ?>/images/2.jpg"/>
		</div> </a>
	<a href="security">
		<div class="menuitem span2" style="margin:0;">
			<div id="security" class="menu-text">
				Security
			</div>
			<div class="menu-bottom-slide"></div>
			<img class="menu-image-normal" src="<?php bloginfo( 'template_directory' ) ?>/images/3.jpg"/>
		</div> 
	</a>
	<a href="/pricing">
		<div class="menuitem span2" style="margin:0;">
			<div id="pricing" class="menu-text">
				Pricing
			</div>
			<div class="menu-bottom-slide"></div>
			<img class="menu-image-normal" src="<?php bloginfo( 'template_directory' ) ?>/images/4.jpg"/>
		</div> </a>

	<div class="login-btn-container  menuitem span2" style="width:113px; height:40px; margin: 11px 0 0 4.8%;">
		<div class="login-btn" >
			<i class="icon-lock icon-white"></i> SIGN IN
		</div>
	</div>

</div>