<?php

/*
 * Functions file
 * Includes all necesary files
 *
 * @package custom
 */


register_sidebar( array(
	'id'	=> 'how-it-works',
	'name'	=> __( 'How it Works Widget', 'minimum' ),
	'description'	=> __( 'How it Works Widget that has links of pages from the Home tabs.', 'minimum' ),
) );


function register_my_menus() {
	register_nav_menus(
			array(
				'primary-menu' => __( 'Primary Menu' ),
				'how-it-works-menu' => __( 'How it Works Menu' )
			)
	);
}

add_action( 'init', 'register_my_menus' );

function clean_custom_menus() {
	$menu_name = 'primary-menu'; // specify custom menu slug
	if ( ($locations = get_nav_menu_locations()) && isset( $locations[$menu_name] ) ) {
		$menu = wp_get_nav_menu_object( $locations[$menu_name] );
		$menu_items = wp_get_nav_menu_items( $menu->term_id );		
		$menu_images = array(
		"http://marginmentor.co.za/wp-content/uploads/What-is-MM-menu.jpg",
		"http://marginmentor.co.za/wp-content/uploads/Why-you-need-it-menu.jpg",
		"http://marginmentor.co.za/wp-content/uploads/How-it-works-menu.jpg",
		"http://marginmentor.co.za/wp-content/uploads/Security-menu.jpg",
		"http://marginmentor.co.za/wp-content/uploads/Pricing-menu.jpg"
		);
		$imagesCount = 0;
		$menu_list = '<ul id="sdt_menu" class="sdt_menu">';
		foreach ( (array) $menu_items as $key => $menu_item ) {
			$title = $menu_item->title;
			$url = $menu_item->url;
			
			$menu_list .= '<li id="menu'. ++$imagesCount .'">';
			$menu_list .=	'<a href="' . $url . '">';			
			$menu_list .=		'<img src="' . $menu_images[--$imagesCount] . '"/>';			
			$menu_list .=			'<span class="sdt_active"></span>';
			$menu_list .=			'<span class="sdt_wrap">';
			$menu_list .=				'<span class="sdt_link ">' . $title . '</span>';			
			$menu_list .=			'</span>';			
			$menu_list .=	'</a>';			
			$menu_list .= '</li>';	
			$imagesCount++;		
		}		
		$menu_list .= '</ul>'; //closing for menu list
		
		$menu_list .= '<div class="login-btn-container menuitem row-fluid " style="width:192px; margin: 20px 0 0 0; position: absolute; right:-5px;">';
		$menu_list .= 		'<div class="span6 signup-btn">';
		$menu_list .= 		'<img src="http://marginmentor.co.za/wp-content/uploads/sign-up.jpg"/></div>';
		
		$menu_list .= 		'<div class="span6 login-btn">';
		$menu_list .= 		'<img src="http://marginmentor.co.za/wp-content/uploads/login.jpg"/></div>';
		$menu_list .= '</div>'; //closing div for login button
		
		
		
	} else {
		 $menu_list = 'no list defined';
	}
	echo $menu_list;
}

function custom_how_it_works_menus() {
	$menu_name = 'how-it-works-menu'; // specify custom menu slug
	if ( ($locations = get_nav_menu_locations()) && isset( $locations[$menu_name] ) ) {
		$menu = wp_get_nav_menu_object( $locations[$menu_name] );
		$menu_items = wp_get_nav_menu_items( $menu->term_id );		
				
		$themeRoute = get_template_directory_uri();
		$menu_list = '<ul class="side-menu span3" style="width: 180px; margin: 0 0 60px 0;">';
		foreach ( (array) $menu_items as $key => $menu_item ) {
			$title = $menu_item->title;
			$url = $menu_item->url;			
			$removedSpaces = str_replace(' ', '', $title);
					
			$menu_list .=		' <li class="side-menuitem"  id="'. $removedSpaces .'">';
			$menu_list .=			'<div class="side-menuitem-title">' . $title .'</div>';
			$menu_list .=			'<img class="pointer-image" src="http://marginmentor.co.za/wp-content/uploads/how-it-works-pointer.jpg"/>';
			$menu_list .=			'<div class="ajaxloader" style="opacity: 0;"><img src="http://marginmentor.co.za/wp-content/uploads/ajaxLoader.gif"/></div>';
			$menu_list .=			'<i class="side-menuitem-link">' . $url.'</i>';									
			$menu_list .=		'</li>';
			
							
		}		
		$menu_list .= '</ul>'; //closing div for menu		
	} else {
		 $menu_list = 'no list defined';
	}
	echo $menu_list;
}

?>