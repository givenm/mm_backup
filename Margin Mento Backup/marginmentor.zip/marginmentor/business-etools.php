<div id="content">
	<div class="row-fluid info-content-strip  strip-1" style="height: 360px; padding-top: 65px;">
		<div class="row-fluid page-top-heading">
			<div class="span12">Improve your business performance</div>
		</div>
		<div class="row-fluid">
			<div class="span6" style="margin-top: 40px;">
				<div class="row-fluid">
					<div class="page-strip-subheading" >Easy to use eTools for improved business performance</div>
				</div>	
				<div class="row-fluid">
					Our  SME eTools are designed to help business owners devlop action plans to improve their business performance and profitability.
				</div>						
			</div>
			<div class="span6" style="padding-top: 40px;"><img src="http://marginmentor.co.za/wp-content/uploads/etools-1.jpg" alt="Some image"/></div>
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-2" style="height: 250px">
		<div class="span6" ><img src="http://marginmentor.co.za/wp-content/uploads/etools-2.jpg"/></div>
		<div class="span6" style="margin-top: 20px">
			<div class="row-fluid">
				<div class="page-strip-subheading" >Diagnostic Assessment Tool</div>
			</div>			
			<div class="row-fluid">
				Margin Mentor&#39;s business diagnostic tool is an interactive on-line questionnaire or checklists 
				that provide a framework to assist you the business owner to review the operations of your business and identify possible areas for improvement.
			</div>			
		</div>			
	</div>
	
	<div class="row-fluid info-content-strip  strip-3" style="height: 250px">	
		<div class="span6" style="margin-top: 40px">	
			<div class="row-fluid">
				<div class="page-strip-subheading" >Funding tutorial</div>
			</div>			
			<div class="row-fluid">
				Money represents the lifeline of every business.  With our funding tutorial we will increase your chances of securing a business loan.
			</div>			
		</div>
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/etools-3.jpg"/></div>
	</div>	
	
	<div class="row-fluid info-content-strip  strip-4" style="height: 250px">
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/etools-4.jpg"/></div>		
		<div class="span6" style="margin-top: 10px">	
			<div class="row-fluid">
				<div class="page-strip-subheading">Budgeting module</div>
			</div>			
			<div class="row-fluid">
				With our budgeting tutorial we will show you how to spend your money with intention. Budgeting lies 
				at the foundation of every financial plan. Unlike what you might believe, budgeting isn&#39;t all about 
				restricting what the company spends. It&#39;s really about understanding how much money you have, where it 
				goes, and then planning how to best allocate those funds to achieve your business objectives.
			</div>			
		</div>			
	</div>	
	
	<div class="row-fluid info-content-strip  strip-5" style="height: 390px">			
		<div class="span6" style="margin-top: 10px">			
			<div class="row-fluid">
				The tutorial will show you why a budget is so important? On the surface it seems like creating a
				 budget is just a tedious financial exercise, but you might be surprised at just how valuable a budget 
				 can be. A good budget can help keep your spending on track and even uncover some hidden cash flow problems 
				 that might free up even more money to put toward other financial goals. 
			</div>			
		</div>	
		<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/etools-5.jpg"/></div>	
		<div class="row-fluid" style="margin-bottom:10px;">
			A budget is at the cornerstone of a solid financial foundation, regardless of the company&#39;s situation, and 
			we will show you that it isn’t that hard to do.The tutorial will show that a budget is nothing more than a 
			breakdown and plan of how much money you have coming in and where it goes, keeping track of your income and
			 expenses? If you don’t know how much money you have coming in and where it goes, your road to financial 
			 success will be a difficult one.
		</div>	
	</div>
	
	<div class="row-fluid info-content-strip  strip-6" style="height: 350px">
		<div class="row-fluid">
			<div class="page-strip-subheading" >Digital company profile</div>
		</div>	
		<div class="row-fluid">
			<div class="span6"><img src="http://marginmentor.co.za/wp-content/uploads/etools-6.jpg"/></div>			
			<div class="span6">			
				<div class="row-fluid">
					We will assist you to create a digital company profile for your business.  All your company&#39;s essential 
					documents are digitized and stored electronically. 
				</div>	
				<div class="row-fluid">
					<ul>
						<li>Secretarial documents </li>
						<li>Tax clearance certificate</li>
						<li>Empowerment certificates</li>
						<li>VAT clearance certificate</li>
					</ul>
				</div>
				<div class="row-fluid">
					You can then access these documents at anytime from anyhere.
				</div>
			</div>	
		</div>					
	</div>	
</div>