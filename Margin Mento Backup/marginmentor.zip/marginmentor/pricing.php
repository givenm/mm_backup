<div class="row-fluid " style="margin-top:37px; margin-bottom: 10px; color: rgb(94, 107, 111);">
	<div class="row-fluid page-top-heading">
		<div class="span12" style="font-family: Tahoma, 'sans-sarif';">Pricing</div>
	</div>
	<div class="row-fluid" style="height: 30px; margin: 10px 0 10px 0; font-family: Tahoma, 'sans-sarif';">
		Feature updates, automatic backups, support and more.
		<span style="color: rgb(153, 204, 225); font-weight: bold; font-size: 15px;">Get started now and build your profitable and sustainable business.</span>
	</div>
	<div class="row-fluid" style="margin: 25px 0 40px 0; overflow: visible;">
		<!-- DC Pricing Tables:1 Start -->
		<div class="clear" id="tsc_pricingtable01">
			<div class="plan b-one" id="most-popular">
				<h3>
					Professional
					<span class="price-tag">
					<span style="left: 4px; top: -3px;" class="rand-superscript">R</span>
					<span style="margin-left: 10px;">30,700</span></span>
				</h3>				
				<ul>
					<li class="subscrition">One Year Subscription</li>
					<li class="features" banner="b-one">
						<span>Features</span>
						<span>
							<img class="grey-sample-arrow" style="display: inline;"  src="//marginmentor.co.za/wp-content/uploads/grey-sample-arrow.jpg"/>
							<img class="blue-sample-arrow" style="display: none;" src="//marginmentor.co.za/wp-content/uploads/blue-sample-arrow.jpg"/>
						</span>
						<input type="hidden" class="feature-tab-num" value="0" />
					</li>	
					<li>
						<span class="sample">
							<span><a href="#myModal" role="button" data-toggle="modal">View Sample</a></span>																			
						</span>
					</li>					
				</ul>
				<div ><img class="buy" src="//marginmentor.co.za/wp-content/uploads/buy.png"/></div>
			</div>
			
			<div class="plan b-two">				
				<h3>
					Business Diagnostic Tool
					<span class="price-tag">
					<span style="left: 24px; top: -5px;" class="rand-superscript">R</span>
					<span style="margin-left: 7px;">800</span></span>
				</h3>
				
				<ul>
					<li class="subscrition">Once-Off Purchase</li>
					<li class="features" banner="b-two">
						<span>Features</span>
						<span>
							<img class="grey-sample-arrow" style="display: inline;"  src="//marginmentor.co.za/wp-content/uploads/grey-sample-arrow.jpg"/>
							<img class="blue-sample-arrow" style="display: none;" src="//marginmentor.co.za/wp-content/uploads/blue-sample-arrow.jpg"/>
						</span>
						<input type="hidden" class="feature-tab-num" value="1" />
					</li>	
					<li>
						<span class="sample">
							<span><a href="#myModal" role="button" data-toggle="modal">View Sample</a></span>																			
						</span>
					</li>					
				</ul>
				<div><img class="buy" src="//marginmentor.co.za/wp-content/uploads/buy.png"/></div>
			</div>
			
			<div class="plan b-three">				
				<h3>
					Funding Tutorial
					<span class="price-tag">
					<span style="left: 24px; top: -5px;" class="rand-superscript">R</span>
					<span style="margin-left: 7px;">800</span></span>
				</h3>
				<ul>
					<li class="subscrition">Once-Off Purchase</li>
					<li class="features" banner="b-three">
						<span>Features</span>
						<span>
							<img class="grey-sample-arrow" style="display: inline;"  src="//marginmentor.co.za/wp-content/uploads/grey-sample-arrow.jpg"/>
							<img class="blue-sample-arrow" style="display: none;" src="//marginmentor.co.za/wp-content/uploads/blue-sample-arrow.jpg"/>
						</span>
						<input type="hidden" class="feature-tab-num" value="2" />
					</li>	
					<li>
						<span class="sample">
							<span><a href="#myModal" role="button" data-toggle="modal">View Sample</a></span>																			
						</span>
					</li>					
				</ul>
				<div><img class="buy" src="//marginmentor.co.za/wp-content/uploads/buy.png"/></div>
			</div>
			
			
			<div class="plan b-four">				
				<h3>
					Budgeting Module
					<span class="price-tag">
					<span style="left: 24px; top: -5px;" class="rand-superscript">R</span>
					<span style="margin-left: 7px;">800</span></span>
				</h3>				
				<ul>
					<li class="subscrition">Once-Off Purchase</li>
					<li class="features" banner="b-four">
						<span>Features</span>
						<span>
							<img class="grey-sample-arrow" style="display: inline;"  src="//marginmentor.co.za/wp-content/uploads/grey-sample-arrow.jpg"/>
							<img class="blue-sample-arrow" style="display: none;" src="//marginmentor.co.za/wp-content/uploads/blue-sample-arrow.jpg"/>
						</span>
						<input type="hidden" class="feature-tab-num" value="3" />
					</li>	
					<li>
						<span class="sample">
							<span><a href="#myModal" role="button" data-toggle="modal">View Sample</a></span>																			
						</span>
					</li>					
				</ul>
				<div><img class="buy" src="//marginmentor.co.za/wp-content/uploads/buy.png"/></div>
			</div>
			
			
			<div class="plan b-five">				
				<h3>
					Digital Company Profile
					<span class="price-tag">
					<span style="left: 13px; top: -3px;" class="rand-superscript">R</span>
					<span style="margin-left: 7px;">1,500</span></span>
				</h3>				
				<ul>
					<li class="subscrition">Once-Off Purchase</li>
					<li class="features" banner="b-five">
						<span>Features</span>
						<span>
							<img class="grey-sample-arrow" style="display: inline;"  src="//marginmentor.co.za/wp-content/uploads/grey-sample-arrow.jpg"/>
							<img class="blue-sample-arrow" style="display: none;" src="//marginmentor.co.za/wp-content/uploads/blue-sample-arrow.jpg"/>
						</span>
						<input type="hidden" class="feature-tab-num" value="4" />
					</li>	
					<li>
						<span class="sample">
							<span><a href="#myModal" role="button" data-toggle="modal">View Sample</a></span>																			
						</span>
					</li>					
				</ul>
				<div><img class="buy" src="//marginmentor.co.za/wp-content/uploads/buy.png"/></div>
			</div>
									
		</div>
		<!-- DC Pricing Tables:1 End -->	
	</div>
	
	<div class="row-fluid" style="margin: 0 0 80px 0; font-family: Tahoma, 'sans-sarif';">
		<div class="pricing-tab-container">
			<ul id="myTab" class="nav nav-tabs" style="margin-bottom: -1px;">
				<li class="active" style="cursor: default;">
					<a href="#tab-1" data-toggle="tab">						
						<img style="max-width: 150px; display: block;" src="//marginmentor.co.za/wp-content/uploads/tab-1-text.png"/>						
					</a>
				</li>
				<li class="" >
					<a class="disabled" href="#tab-2" data-toggle="tab" style="padding-top:0; padding-bottom:0;">											
						<img style="max-width: 150px;  display: none" src="//marginmentor.co.za/wp-content/uploads/tab-2-text.png"/>						
					</a>
				</li>
				<li class="" >
					<a href="#tab-3" data-toggle="tab" style="padding-top:0; padding-bottom:0;">						
						<img style="max-width: 150px;  display: none; padding-top:0; padding-bottom:0;" src="//marginmentor.co.za/wp-content/uploads/tab-3-text.png"/>						
					</a>
				</li>
				<li class="" >
					<a href="#tab-4" data-toggle="tab" style="padding-top:0; padding-bottom:0;">						
						<img style="max-width: 150px;  display: none; padding-top:0; padding-bottom:0;" src="//marginmentor.co.za/wp-content/uploads/tab-4-text.png"/>						
					</a>
				</li>
				<li class="" >
					<a href="#tab-5" data-toggle="tab" style="padding-top:0; padding-bottom:0;">						
						<img style="max-width: 150px;  display: none; padding-top:0; padding-bottom:0;" src="//marginmentor.co.za/wp-content/uploads/tab-5-text.png"/>						
					</a>
				</li>
												
			</ul>
			<div id="myTabContent" class="tab-content" style="width: 936px">
				<div class="tab-pane fade active in" id="tab-1">
					<div class="row-fluid">
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/green-tick.jpg"/>
							</div>
							<div class="span3">
								<span class="text-title">Literacy Test</span>
							</div>
							<div class="span7">
								Complete our on-line test to establish your level of financial literacy.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/green-tick.jpg"/>
							</div>
							<div class="span3">
								<span class="text-title">Financial Worksop</span>
							</div>
							<div class="span7">
								Attend a 2-Day Workshop for two company delegates, teaching you the fundamentals of financial management.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/green-tick.jpg"/>
							</div>
							<div class="span3">
								<span class="text-title">FMIS</span>
							</div>
							<div class="span7">
								Get 24-Hour access to our Financial Management Information System providing access for two users of your company.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/green-tick.jpg"/>
							</div>
							<div class="span3">
								<span class="text-title">Business Diagnostic Tool</span>
							</div>
							<div class="span7">
								Use our on-line diagnostic tool providing you with a gauge and rating, to establish your funding readiness.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/green-tick.jpg"/>
							</div>
							<div class="span3">
								<span class="text-title">Funding Tutorial</span>
							</div>
							<div class="span7">
								Enabling you to become investment ready by detailing the various requirements of financial institutions.
							</div>
						</div>
						
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/green-tick.jpg"/>
							</div>
							<div class="span3">
								<span class="text-title">Budgeting Module</span>
							</div>
							<div class="span7">
								Learn how to use the power of budgets to drive financial performance of your business.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/green-tick.jpg"/>
							</div>
							<div class="span3">
								<span class="text-title">Digital Company Profile</span>
							</div>
							<div class="span7">
								Create your digital company profile in the cloud where you access and update from anywhere, anytime.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/green-tick.jpg"/>
							</div>
							<div class="span3">
								<span class="text-title">Assist</span>
							</div>
							<div class="span7">
								Receive the services of a dedicated Margin Mentor advisor who will visit your company every month for 12 months.
							</div>
						</div>
					</div>
				</div>
				
				<div class="tab-pane fade" id="tab-2">
					<div class="row-fluid">
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-2-img-1.jpg"/>
							</div>
							<div class="span7">
								Our business diagnostic tool is an interactive on-line questionnaire or checklist that provides a framework to assist you the business owner to review the operations of your business and identify possible areas for improvement
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-2-img-2.jpg"/>
							</div>
							<div class="span7">
								The purpose of the Margin Mentor business diagnostic tool is for it to be an action oriented enterprise development implement. It&#39;s not enough to just identify opportunities for improvement - we want you to develop strategies and an action plan for acting upon those opportunities.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-2-img-3.jpg"/>
							</div>
							<div class="span7">
								Within the tool, you are encouraged to first answer a series of questions about your business, background, objectives, skills, strengths and weaknesses, and management practices. 
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-2-img-4.jpg"/>
							</div>
							<div class="span7">
								It also provides a framework for reviewing the operations of your business and identifying opportunities for improvement. Once you have identified several priorities for improvement, the business diagnostic tool assists you to prepare strategies and an action plan for acting on those opportunities.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-2-img-5.jpg"/>
							</div>
							<div class="span7">
								The Business Diagnostic Tool is designed to be only a guide to aid in the review of skills, management practices and business performance and should be used in conjunction with other resources. It is not intended to replace legal, accounting or other professional services or advice.
							</div>
						</div>
					</div>
				</div>
				
				<div class="tab-pane fade" id="tab-3">
					<div class="row-fluid">
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-3-img-1.jpg"/>
							</div>
							<div class="span7">
								Caught up in the nasty cycle in which you are unable to boost your sales and profit because you don&#39;t have the resources to make the necessary investments for growth?
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-3-img-2.jpg"/>
							</div>
							<div class="span7">
								Use our funding tutorial to untangle yourself from this web of stunted development.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-3-img-3.jpg"/>
							</div>
							<div class="span7">
								Enhance your eligibility to secure a business loan which can supply a much needed infusion of cash, helping jump start your company as a whole and subsidize growth.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-3-img-4.jpg"/>
							</div>
							<div class="span7">
								Learn about the pitfalls of business loans.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-3-img-5.jpg"/>
							</div>
							<div class="span7">
								Increase your chances of securing a business loan by following our clearly defined application steps.
							</div>
						</div>
					</div>
				</div>
				
				<div class="tab-pane fade" id="tab-4">
					<div class="row-fluid">
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-4-img-1.jpg"/>
							</div>
							<div class="span7">
								Budgeting lies at the foundation of every financial plan.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-4-img-2.jpg"/>
							</div>
							<div class="span7">
								With our budgeting tutorial you will learn that it doesn’t matter if you’re turning over R10,000 or R10 million, you need to know where your money is going if you want to have a handle on your business finances.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-4-img-3.jpg"/>
							</div>
							<div class="span7">
								Unlike what you might believe, budgeting isn’t all about restricting what the company spends.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-4-img-4.jpg"/>
							</div>
							<div class="span7">
								It&#39;s really about understanding how much money you have, where it goes, and then planning how to best allocate those funds to achieve your business objectives.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-4-img-5.jpg"/>
							</div>
							<div class="span7">
								The tutorial will show you why a budget is so important.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-4-img-6.jpg"/>
							</div>
							<div class="span7">
								The tutorial will show that a budget is nothing more than a breakdown and plan of how much money you have coming in and where it goes, keeping track of your income and expenses? If you don’t know how much money you have coming in and where it goes, your road to financial success will be a difficult one.
							</div>
						</div>
					</div>
				</div>
				
				<div class="tab-pane fade" id="tab-5">
					<div class="row-fluid">
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-5-img-1.jpg"/>
							</div>
							<div class="span7">
								Are you spending a great deal of time and energy in preparing and submitting tender bids?
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-5-img-2.jpg"/>
							</div>
							<div class="span7">
								If you are, then generally there are two types of activities you are engaged in, in submitting a tender: the first involves preparing compliance documentation and the second is in documenting your functional capability and price.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-5-img-3.jpg"/>
							</div>
							<div class="span7">
								Spend less time in preparing compliance documentation by storing and updating these in our digital company profile portal.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-5-img-4.jpg"/>
							</div>
							<div class="span7">
								Documents such as shareholders certificates, tax compliance certificates broad-based black economic empowerment ratings certificates and many others can be stored safely and securely in our cloud repository.
							</div>
						</div>
						<div class="row-fluid tab-pane-row">
							<div class="span1">
								
							</div>
							<div class="span2">
								<img class="buy" src="//marginmentor.co.za/wp-content/uploads/tab-5-img-5.jpg"/>
							</div>
							<div class="span7">
								When compiling your tender documents you can effortlessly access your compliance certificates from anywhere so that you can focus your attention on the more important part of the tender, your business proposal.
							</div>
						</div>						
					</div>
				</div>
				
				
			</div>
	  	</div>
	  		
	</div> <!--End of Row -->
	
	<div class="row-fluid back-to-top span12" align="right" style="font-weight: bold; font-size:13px; color: blue; margin:-75px 0 20px 0px;">Back To Top</div>
	
	<div class="row-fluid" style="margin: 20px 0 40px 0; font-family: Tahoma, 'sans-sarif';">
		<div class="row-fluid">
			<div class="span12 page-strip-subheading">Questions?</div>
		</div>
		<div class="row-fluid">
			<div class="span12 questions-links">Do I have to sign a contract?</div>
		</div>
		<div class="row-fluid">
			<div class="span12 questions-links">When will I be billed?</div>
		</div>
		<div class="row-fluid">
			<div class="span12 questions-links">When does my subscription commence?</div>
		</div>
		<div class="row-fluid">
			<div class="span12 questions-links">What type of payment do you accept?</div>
		</div>
		<div class="row-fluid">
			<div class="span12 questions-links">Can I cancel at anytime?</div>
		</div>
		<div class="row-fluid">
			<div class="span12 questions-links">How do I cancel my account?</div>
		</div>
	</div>
	
	<div class="row-fluid" style="margin: 20px 0 40px 0; font-family: Tahoma, 'sans-sarif';">
		<div class="row-fluid">
			<div class="span12 questions-links">Where can we review your terms of use and privacy policy?</div>
		</div>
		<div class="row-fluid">
			<div class="span12">Here are our <a class="inline-pricing-links" href="//marginmentor.co.za/terms-of-use/">Terms of Use</a>. We maintain all user data under strict privacy policy. 
			For more information view our <a class="inline-pricing-links" href="//marginmentor.co.za/privacy-and-security-policy">Privacy Policy</a>.</div>
		</div>
	</div>
	
	<div class="row-fluid" style="margin: 20px 0 40px 0; font-family: Tahoma, 'sans-sarif';">
		<div class="row-fluid">
			<div class="span12 questions-links">What if I have other questions?</div>
		</div>
		<div class="row-fluid">
			<div class="span12">Please <a class="inline-pricing-links" href="#">contact us</a> for tech support, customer service, or anything else.</div>
		</div>
	</div>
</div>