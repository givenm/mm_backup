<div id="content">
	<div class="row-fluid info-content-strip  strip-1" style="height: 200px; padding-top: 65px;">
		<div class="row-fluid page-top-heading">
			<div class="span12">Learn how to interpret and analyze your financial statements</div>
		</div>		
		<div class="row-fluid" style="margin-top:20px;">
			As a business owner you need to understand financial concepts and analysis for the purpose od achieving the
			 operating goals of your company.  Our MarginTutor programme will teach you this understanding.		
		</div>		
	</div>
	
	<div class="row-fluid info-content-strip  strip-2" style="height: 260px">		
		<div class="row-fluid" style="margin-top:0px;">
			<div class="page-strip-subheading" >Test yourself</div>
		</div>
		<div class="row-fluid">
			<div class="span5">			
				<div class="row-fluid">
					Complete this on-line financial literacy test which will enable you as  a business owners to
					 gauge of your general understanding and capability in interpreting your  company&#39;s financial 
					 performance.  The test is a multiple choice format and scoring and result publication will be generated on-line. 
				</div>			
			</div>
			<div class="span7" style="margin-top:-80px;"><img src="http://marginmentor.co.za/wp-content/uploads/education-1.jpg"/></div>			
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-3" style="height: 392px">
		<div class="row-fluid">
			<div class="page-strip-subheading" >Back to School</div>
		</div>	
		<div class="row-fluid">
			<div class="span7" ><img src="http://marginmentor.co.za/wp-content/uploads/education-2.jpg"/></div>			
			<div class="span5">							
				<p>
					Increase your financial literacy with our 2-day short course. These formal lectures are conducted
					 in laymans language  within a non-pressurised  environment. You will come away from these sessions:
				</p>
				<p>
					<ul style="margin-left: 16px;">
						<li>Having a theoretical grounding of the concepts and rules used in preparing your management 
						accounts and financial statements.</li>
						<li>Knowing  how to interpret your financial statements.</li>
						<li>Being able to conduct financial ratio analysis and knowing how these ratios impact the financial health of your company.</li>						
					</ul>
				</p>			
			</div>						
		</div>
	</div>	
	
	
	
	<div class="row-fluid info-content-strip  strip-6" style="height: 670px; margin-left: -220px; width: 930px;">		
		<div class="row-fluid" >
			<div class="page-strip-subheading" >Embedded Financial Literacy aids</div>
		</div>
		<div class="row-fluid">
			Access the financial dictionary of pop-up box  explanations which are embedded in our financial manangement 
			information system software. Get instant explanations of any financial term  or concept while viewing  your 
			financial statements, scorecard or dashboard. On-line tutorials in how to interpret your statement of comprehensive 
			income, statement of financial position, statement of cash flows and ratio analysis are always available to re-inforce your financial literacy. 
		</div>			
		
		<div class="row-fluid" style="margin-top:25px;"><img src="http://marginmentor.co.za/wp-content/uploads/education-3.jpg"/></div>								
	</div>	
</div>