<div id="content">
	<div class="row-fluid info-content-strip  strip-" style="height: 572px; padding-top: 65px;">
		<div class="row-fluid page-top-heading">
			<div class="span12">SME ePlatform for Profitability</div>
		</div>
		<div class="row-fluid" style="margin-top:30px;">
			<div class="span8 page-strip-subheading">Increase your managerial <br>competency</div>
		</div>
		<div class="row-fluid">
			<div class="span5">			
				<div class="row-fluid">
					Increase your managerial competency and business sophistication with our platform for 
					profitability. Our platform is underpinned by the strategic pillars of <b>EDUCATION</b>, 
					<b>VISUALIZATION</b>, <b>MITIGATION</b>  and <b>ASSISTANCE</b>.  
				</div>
				<div class="row-fluid" style="margin-top:217px;">These pillars translates into our offering which:</div>		
			</div>
			<div class="span7" style="margin-top:-60px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-1.jpg"/></div>			
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-2" style="height: 260px">
		<div class="row-fluid">
			<div class="span3" style="margin-top:60px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-2-1.jpg"/></div>
			<div class="span5" style="margin-top:5px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-2-2.jpg"/></div>
			<div class="span4" style="margin-top:70px;">			
				<div class="row-fluid">
					Enables you to test your <strong>financial literacy</strong> levels with our on-line test and scoring. 
				</div>			
			</div>						
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-3" style="height: 260px">
		<div class="row-fluid">			
			<div class="span4" style="margin-top:70px;">			
				<div class="row-fluid">
					Our a dedicated program of disseminating <strong>financial education</strong> targeted at SME owners. 
				</div>			
			</div>		
			<div class="span5" style="margin-top:10px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-3-1.jpg"/></div>
			<div class="span3" style="margin-top:60px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-3-2.jpg"/></div>				
		</div>
	</div>	
	
	<div class="row-fluid info-content-strip  strip-4 " style="height: 260px">
		<div class="row-fluid">
			<div class="span3" style="margin-top:60px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-4-1.jpg"/></div>
			<div class="span5" style="margin-top:5px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-4-2.jpg"/></div>
			<div class="span4" style="margin-top:35px;">			
				<div class="row-fluid">
					The web-based <strong>financial management information system</strong> which will enable you to measure, monitor and manage
					 the financial performance of your company. 
				</div>			
			</div>						
		</div>
	</div>
	
	<div class="row-fluid info-content-strip  strip-5" style="height: 300px">
		<div class="row-fluid">
			<div class="span3" ><img src="http://marginmentor.co.za/wp-content/uploads/overview-5-1.jpg"/></div>			
			<div class="span4" style="margin-top:80px;">			
				<div class="row-fluid">
					A suite of intuitive  business development eTools designed to enhance your business sophistication.
				</div>			
			</div>	
			<div class="span5" style="margin-top:75px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-5-2.jpg"/></div>					
		</div>
	</div>	
	
	<div class="row-fluid info-content-strip  strip-6" style="height: 250px">
		<div class="row-fluid">
			<div class="span3" style="margin-top:55px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-6-1.jpg"/></div>			
			<div class="span4" style="margin-top:75px;">			
				<div class="row-fluid">
					Your own dedicated Margin Mentor advisor.
				</div>
			</div>
			<div class="span5" style="margin-top:8px;"><img src="http://marginmentor.co.za/wp-content/uploads/overview-6-2.jpg"/></div>					
		</div>
	</div>
</div>